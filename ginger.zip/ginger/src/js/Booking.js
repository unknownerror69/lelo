function getBookings() {
	var url = "../booking.json";
	// Ajax Call : on selecting the location and date of booking make an ajax call
	// Check if the date is a valid date (call the validate date method) - Populate error message if the user has entered a past date
	// Check if there is any availability in the selected location on the date of booking
	// Populate error message if there is no availability in the location on the selected date
	var xhr=new XMLHttpRequest();
	xhr.open('GET',url);
	xhr.onload=function(){
		if(validateDate(document.getElementById('dor').value,Date.now)){
			var obj=JSON.parse(xhr.responseText)
			var obj1=obj[document.getElementById('location').value]
			obj1.forEach(element => {
				if(element==document.getElementById('dor').value){
					document.getElementById('dateError').innerText="Housefull!Booking is not available on this date";
				} 
				else{
					document.getElementById('dateError').innerText="";
					document.getElementById('btn').disabled=false;
				}
			});
		}
	}
	xhr.send();
}


/* Debug the below code to display the appropriate booking/success message */
function book() {

	// Charges for one person for one day is 100$
	// If the Number of people is less than 5 no discount is offered
	// If the number of people is more than 5 and less than 15 then a discount of 5% is offered
	// If the number of people is more than 14 and less than 21 a discount of 10% should be offered

	var nop = document.getElementById('nop').value;
	var cost = (nop * 100);
	var cost1 = ((nop * 100 - (nop * 5)) / 100)*100;
	var cost2 = ((nop * 100 - (nop * 10)) / 100)*100;
	console.log(nop);

	if (nop > 5 && nop <= 15) {
		document.getElementById("successMessage").innerText= "Successful booking.Total amount to be paid is: $" + cost1;
		console.log(cost1)
	} else if (nop >= 14 && nop <= 21) {
		document.getElementById("successMessage").innerText = "Successful booking.Total amount to be paid is: $" + cost2;
		console.log(cost2)
	} else {
		document.getElementById("successMessage").innerText = "Successful booking.Total amount to be paid is: $" + cost;
		console.log(cost)
	}

	return false
}



function validateDate(bookingDate, todayDate) {
	// write the code to return true if bookingDate is after todayDate and false if bookingDate is a past date
	if(bookingDate>todayDate){
		return true;
	}
	return true;
}







