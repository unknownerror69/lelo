const dbLayer = require('../model/Products');

let product={}

product.getProductsByCategory = (category) => {
    return dbLayer.getProductsByCategory(category).then( response => {
        return response
    })
}
product.getAllProductCategories = () => {
    return dbLayer.getAllProductCategories().then( response => {
        return response
    })
}
product.searchProduct = (fetch) => {
    return dbLayer.searchProduct(fetch).then( response => {
        return response
    })
}
product.productdetails = (fetch) => {
    return dbLayer.productdetails(fetch).then( response => {
        return response
    })
}

module.exports = product