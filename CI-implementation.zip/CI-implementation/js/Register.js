// cityArr="hi";

let ageValid = false;


function getFromSession() {
	let cityArr = []
	var url = "./types.json";
	var xhr = new XMLHttpRequest();
	xhr.open('GET', url);
	xhr.onload = function () {
		try {
			obj = JSON.parse(xhr.responseText);
			type = sessionStorage.getItem('interest');
			cityArr = obj[type].city
			if (type == "healthy") {
				document.getElementById('type').innerText = "Register for Nutrition cooking class"
				var values = obj[type].varieties;
			} else if (type == "desserts") {
				document.getElementById('type').innerText = "Register for Desserts cooking class"
				var values = obj[type].varieties;
			} else if (type == "regulars") {
				document.getElementById('type').innerText = "Register for Regular cooking class"
				var values = obj[type].varieties;
			}

			for (var i = 0; i < values.length; i++) {
				document.getElementById('list').innerHTML += "<li>" + values[i] + "</li>"
			}
		}
		catch (err) {
			document.getElementById('list').innerHTML = `<span class="text-danger">Couldn't fetch data</span>`
		}
		finally {
			showDropdown(cityArr);
		}
	};
	xhr.send();

}



function showDropdown(cityArr) {
	var d = new Date()
	let presentTime = d.getHours();
	if (presentTime < 8 && presentTime > 23) {
		document.getElementsByTagName('form')[0].hidden = true;
		document.getElementById('showGreeting').innerHTML = "Sorry We Are Off,Come Back Soon!"
	}
	else if (presentTime > 8 && presentTime < 12) {
		document.getElementById('showGreeting').innerHTML = "Good Morning, Happy To see you"
	}
	else if (presentTime >= 12 && presentTime < 17) {
		document.getElementById('showGreeting').innerHTML = "Good After Noon, Happy To see you"
	}
	else if (presentTime => 17 && presentTime <= 23) {
		document.getElementById('showGreeting').innerHTML = "Good Evening, Happy To see you"
	}
	for (var i = 0; i < cityArr.length; i++) {
		document.getElementById('showDrop').innerHTML += `<option value=${cityArr[i]}>` + cityArr[i] + `</option>`
	}
}

function enableButton() {

	let name = document.getElementById("yourname").value
	let city = document.getElementById("showDrop").value
	if (ageValid && name && city ) {
		document.getElementById('btn').disabled = false
	} else {
		document.getElementById('btn').disabled = true;
	}

}




function checkAge() {
	var age = document.getElementById("age").value
	if (age < 18 || age > 60) {
		document.getElementById("ageError").innerText = "Sorry, You should be between 18-60 years old!"
		document.getElementById("successMessage").innerText = ""
		ageValid = false
	} else {
		document.getElementById("ageError").innerText = ""
		ageValid = true
	}
	enableButton()
}


function register(e) {
	fareObj = {
		"healthy": 4500,
		"desserts": 5000,
		"regulars": 3500,
	}
	var fee = fareObj[type]
	document.getElementById("successMessage").innerText = "Registered! You will be paying " + fee + " at the time of admission"
	sessionStorage.clear();
	e.preventDefault();
}


// Donot remove if Below code

if (typeof exports !== 'undefined') {
	module.exports = {
		register,
		checkAge,
		enableButton,
		showDropdown,
		getFromSession
	};
}