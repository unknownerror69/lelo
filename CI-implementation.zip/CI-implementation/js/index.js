function store(value) {
	sessionStorage.setItem('interest', value);
}
if (typeof exports !== 'undefined') {
	module.exports = {
		store
	};
}