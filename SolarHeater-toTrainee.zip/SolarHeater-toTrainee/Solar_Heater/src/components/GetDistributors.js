import React, { Component } from "react";
import axios from "axios";
import "../App.css";

const url = "http://localhost:2040/findService/";

class GetDistributors extends Component {
  constructor(props) {
    super(props);
    this.state = {
      distributorData: [],
      form: {
        customerLocation: ""
      },
      formErrorMessage: {
        customerLocation: ""
      },
      formValid: {
        customerLocation: false,
        buttonActive: false
      },
      errorMessage: "",
      successMessage: ""
    };
  }

  handleSubmit = (event) => {
    /* prevent page reload and invoke fetchDistributorByLocation() method */
  }

  handleChange = (event) => {
    /* 
      invoke whenever any change happens in any of the input fields
      and update form state with the value. Also, Inoke validateField() method to validate the entered value
    */
  }

  validateField = (fieldName, value) => {
    /* Perform Validations and assign error messages, Also, set the value of buttonActive after validation of the field */
  }

  fetchDistributorByLocation = () => {
    /* 
      Send an AXIOS GET request to the url http://localhost:1050/findService/:customerLocation 
      to fetch all the distributors available in that location
      and handle the success and error cases appropriately 
    */
  }

  render() {
    return (
      <React.Fragment>
        <div className="row">
          <div className="col-md-6 offset-md-3">
            <br />
            <div className="card">
              <div className="card-header bg-custom text-center">
                <h4>View Distributors</h4>
              </div>
              <div className="card-body view">
                {/* code here to get the view as shown in QP for GetDistributors component */}
                {/* display the distributors in an unordered list */}
                {/* Display error message if the server is not running */}
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

export default GetDistributors;