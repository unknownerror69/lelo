import React, { Component } from "react";
import axios from "axios";
import "../App";

const url = "http://localhost:2040/allocate/";

class AllocateSolar extends Component {
  constructor(props) {
    super(props);
    this.state = {
      formValue: {
        distributorName: "",
        purchaseDate: "",
        installationDate: "",
        customerName: "",
        customerLocation: ""
      },
      formErrorMessage: {
        distributorName: "",
        purchaseDate: "",
        installationDate: "",
        customerName: "",
        customerLocation: ""
      },
      formValid: {
        distributorName: false,
        purchaseDate: false,
        installationDate: false,
        customerName: false,
        customerLocation: false,
        buttonActive: false
      },
      successMessage: "",
      errorMessage: ""
    }
  }

  submitAllocation = () => {
    /* 
      Make aN axios PUT request to http://localhost:2040/allocate/:distributorName with form data 
      and handle success and error cases 
    */
  }

  handleSubmit = (event) => {
    /* prevent page reload and invoke submitAllocation() method */
  }

  handleChange = (event) => {
    /* 
      invoke whenever any change happens in any of the input fields
      and update form state with the value. Also, Inoke validateField() method to validate the entered value
    */
  }

  validateField = (fieldName, value) => {
    /* Perform Validations and assign error messages, Also, set the value of buttonActive after validation of the field */
  }

  render() {
    return (
      <React.Fragment>
        <div className="CreateBooking ">
          <div className="container-fluid row">
            <div className="col-md-6 offset-md-3">
              <br />
              <div className="card">
                <div className="card-header bg-custom">
                  <h4>Allocation Form</h4>
                </div>
                <div className="card-body">
                <form onSubmit={this.handleSubmit}>
                                            <div className="form-group">
                                                <label htmlFor="distributorname">Distributor Name</label>
                                                <input type="text" name="distributorname" id="distributorname" className="form-control"  value={this.state.formValue.distributorName} onChange={this.handleChange}/>
                                                <span name="distributorError" className="text-danger">
                                                    {this.state.formErrorMessage.distributorName}
                                                </span>
                                            </div>
                                            <div className="form-group">
                                                <label htmlFor="customername">Customer Name</label>
                                                <input type="text" name="customername" id="customername" className="form-control" value={this.state.formValue.customerName} onChange={this.handleChange}/>
                                                <span name="customerError" className="text-danger">
                                                    {this.state.formErrorMessage.customerName}
                                                </span>
                                            </div>
                                            
                                            {/* <div className="form-group">
                                                <label htmlFor="departureDate">Departure Date</label>
                                                <input type="date" name="departureDate" id="departureDate" className="form-control" value={this.state.form.departureDate} onChange={this.handleChange}/>
                                                <span name="departureDateError" className="text-danger">
                                                    {this.state.formErrorMessage.departureDateError}
                                                </span>
                                            </div>
                                            
                                            <div className="form-group">
                                                <label htmlFor="noOfTickets">No Of Tickets</label>
                                                <input type="number" name="noOfTickets" id="noOfTickets" className="form-control" placeholder="No Of Tickets" value={this.state.form.noOfTickets} onChange={this.handleChange}/>
                                                <span name="noOfTicketsError" className="text-danger">
                                                    {this.state.formErrorMessage.noOfTicketsError}
                                                </span>
                                            </div> */}
                                            
                                            <button name="viewFlightsButton" type="submit" className="btn btn-primary btn-block" disabled={!this.state.formValid.buttonActive}>View Flights</button>
                                        </form>
                                        <span name="errorMessage" className="text-danger text-bold">
                                            {this.state.errorMessage}
                                        </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

export default AllocateSolar;